import React from 'react'
import { Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'

const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-8">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Retour à l'accueil
        </Link>

        <div className="bg-white rounded-lg shadow-sm p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Politique de Confidentialité</h1>
          
          <div className="prose max-w-none">
            <p className="text-gray-600 mb-6">
              <strong>Dernière mise à jour :</strong> {new Date().toLocaleDateString('fr-FR')}
            </p>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">1. Introduction</h2>
              <p className="text-gray-700 mb-4">
                Mon Kit Business s'engage à protéger la confidentialité de vos données personnelles. Cette politique de confidentialité explique comment nous collectons, utilisons, stockons et protégeons vos informations personnelles lorsque vous utilisez notre site web et nos services.
              </p>
              <p className="text-gray-700 mb-4">
                En utilisant notre site web, vous acceptez les pratiques décrites dans cette politique de confidentialité. Si vous n'acceptez pas cette politique, veuillez ne pas utiliser notre site.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">2. Données que nous collectons</h2>
              
              <h3 className="text-xl font-medium text-gray-900 mb-3">2.1 Informations que vous nous fournissez</h3>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Informations de contact (nom, adresse e-mail, numéro de téléphone)</li>
                <li>Informations sur votre entreprise (nom, secteur d'activité, description)</li>
                <li>Données saisies dans nos outils (business plan, projections financières, etc.)</li>
                <li>Communications avec notre équipe de support</li>
              </ul>

              <h3 className="text-xl font-medium text-gray-900 mb-3">2.2 Informations collectées automatiquement</h3>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Adresse IP et informations de géolocalisation approximative</li>
                <li>Type de navigateur et système d'exploitation</li>
                <li>Pages visitées et temps passé sur le site</li>
                <li>Données de cookies et technologies similaires</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">3. Comment nous utilisons vos données</h2>
              <p className="text-gray-700 mb-4">Nous utilisons vos données personnelles pour :</p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Fournir et améliorer nos services</li>
                <li>Personnaliser votre expérience utilisateur</li>
                <li>Communiquer avec vous concernant nos services</li>
                <li>Analyser l'utilisation de notre site pour l'améliorer</li>
                <li>Respecter nos obligations légales</li>
                <li>Prévenir la fraude et assurer la sécurité</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">4. Partage de vos données</h2>
              <p className="text-gray-700 mb-4">
                Nous ne vendons jamais vos données personnelles. Nous pouvons partager vos informations uniquement dans les cas suivants :
              </p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Avec votre consentement explicite</li>
                <li>Avec nos prestataires de services de confiance (hébergement, analytics)</li>
                <li>Pour respecter une obligation légale ou une décision de justice</li>
                <li>Pour protéger nos droits, notre propriété ou notre sécurité</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">5. Cookies et technologies similaires</h2>
              <p className="text-gray-700 mb-4">
                Nous utilisons des cookies pour améliorer votre expérience sur notre site. Les cookies sont de petits fichiers stockés sur votre appareil qui nous aident à :
              </p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Mémoriser vos préférences</li>
                <li>Analyser le trafic du site</li>
                <li>Personnaliser le contenu</li>
                <li>Assurer la sécurité du site</li>
              </ul>
              <p className="text-gray-700 mb-4">
                Vous pouvez gérer vos préférences de cookies via notre bannière de consentement ou les paramètres de votre navigateur.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">6. Vos droits</h2>
              <p className="text-gray-700 mb-4">
                Conformément au RGPD, vous disposez des droits suivants concernant vos données personnelles :
              </p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li><strong>Droit d'accès :</strong> Obtenir une copie de vos données personnelles</li>
                <li><strong>Droit de rectification :</strong> Corriger des données inexactes</li>
                <li><strong>Droit à l'effacement :</strong> Demander la suppression de vos données</li>
                <li><strong>Droit à la limitation :</strong> Limiter le traitement de vos données</li>
                <li><strong>Droit à la portabilité :</strong> Recevoir vos données dans un format structuré</li>
                <li><strong>Droit d'opposition :</strong> Vous opposer au traitement de vos données</li>
              </ul>
              <p className="text-gray-700 mb-4">
                Pour exercer ces droits, contactez-nous à l'adresse : privacy@monkitbusiness.com
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">7. Sécurité des données</h2>
              <p className="text-gray-700 mb-4">
                Nous mettons en place des mesures techniques et organisationnelles appropriées pour protéger vos données personnelles contre :
              </p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>L'accès non autorisé</li>
                <li>La divulgation accidentelle</li>
                <li>La modification non autorisée</li>
                <li>La destruction illégale</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">8. Conservation des données</h2>
              <p className="text-gray-700 mb-4">
                Nous conservons vos données personnelles uniquement pendant la durée nécessaire aux finalités pour lesquelles elles ont été collectées, ou selon les exigences légales applicables.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">9. Transferts internationaux</h2>
              <p className="text-gray-700 mb-4">
                Vos données peuvent être transférées et traitées dans des pays autres que votre pays de résidence. Nous nous assurons que ces transferts respectent les exigences du RGPD.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">10. Modifications de cette politique</h2>
              <p className="text-gray-700 mb-4">
                Nous pouvons modifier cette politique de confidentialité de temps à autre. Les modifications importantes vous seront notifiées par e-mail ou via une notification sur notre site.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">11. Contact</h2>
              <p className="text-gray-700 mb-4">
                Pour toute question concernant cette politique de confidentialité ou le traitement de vos données personnelles, contactez-nous :
              </p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700"><strong>Mon Kit Business</strong></p>
                <p className="text-gray-700">Email : privacy@monkitbusiness.com</p>
                <p className="text-gray-700">Adresse : [Adresse de l'entreprise]</p>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PrivacyPolicy

