import React from 'react'
import { Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'

const TermsOfService = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-8">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Retour à l'accueil
        </Link>

        <div className="bg-white rounded-lg shadow-sm p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Conditions d'Utilisation</h1>
          
          <div className="prose max-w-none">
            <p className="text-gray-600 mb-6">
              <strong>Dernière mise à jour :</strong> {new Date().toLocaleDateString('fr-FR')}
            </p>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">1. Acceptation des conditions</h2>
              <p className="text-gray-700 mb-4">
                En accédant et en utilisant le site web Mon Kit Business et ses services, vous acceptez d'être lié par ces conditions d'utilisation. Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser nos services.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">2. Description du service</h2>
              <p className="text-gray-700 mb-4">
                Mon Kit Business fournit une plateforme en ligne d'outils et de ressources pour aider les entrepreneurs dans la création et le développement de leur entreprise. Nos services incluent :
              </p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Générateur de business plan</li>
                <li>Simulateur financier</li>
                <li>Assistant d'étude de marché</li>
                <li>Checklist de démarrage</li>
                <li>Annuaire de ressources</li>
                <li>Calculateur de statut juridique</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">3. Utilisation acceptable</h2>
              <p className="text-gray-700 mb-4">Vous vous engagez à utiliser nos services uniquement pour des fins légales et conformément à ces conditions. Il est interdit de :</p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Utiliser le service à des fins illégales ou non autorisées</li>
                <li>Tenter d'accéder de manière non autorisée à nos systèmes</li>
                <li>Transmettre des virus, malwares ou autres codes malveillants</li>
                <li>Harceler, menacer ou intimider d'autres utilisateurs</li>
                <li>Violer les droits de propriété intellectuelle</li>
                <li>Utiliser le service pour spammer ou envoyer des communications non sollicitées</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">4. Comptes utilisateur</h2>
              <p className="text-gray-700 mb-4">
                Pour accéder à certaines fonctionnalités, vous devrez peut-être créer un compte. Vous êtes responsable de :
              </p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Maintenir la confidentialité de vos identifiants de connexion</li>
                <li>Toutes les activités qui se produisent sous votre compte</li>
                <li>Nous notifier immédiatement de toute utilisation non autorisée</li>
                <li>Fournir des informations exactes et à jour</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">5. Propriété intellectuelle</h2>
              <p className="text-gray-700 mb-4">
                Le contenu de notre site web, y compris les textes, graphiques, logos, images, et logiciels, est protégé par les lois sur la propriété intellectuelle. Vous ne pouvez pas :
              </p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Reproduire, distribuer ou modifier notre contenu sans autorisation</li>
                <li>Utiliser nos marques commerciales sans permission écrite</li>
                <li>Créer des œuvres dérivées basées sur notre contenu</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">6. Contenu utilisateur</h2>
              <p className="text-gray-700 mb-4">
                Vous conservez la propriété du contenu que vous créez ou téléchargez sur notre plateforme. Cependant, vous nous accordez une licence pour utiliser ce contenu dans le cadre de la fourniture de nos services.
              </p>
              <p className="text-gray-700 mb-4">
                Vous êtes seul responsable du contenu que vous partagez et vous garantissez qu'il ne viole aucun droit de tiers.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">7. Limitation de responsabilité</h2>
              <p className="text-gray-700 mb-4">
                Nos services sont fournis "en l'état" sans garantie d'aucune sorte. Nous ne garantissons pas que :
              </p>
              <ul className="list-disc pl-6 text-gray-700 mb-4">
                <li>Le service sera ininterrompu ou exempt d'erreurs</li>
                <li>Les résultats obtenus seront exacts ou fiables</li>
                <li>Tous les défauts seront corrigés</li>
              </ul>
              <p className="text-gray-700 mb-4">
                Dans la mesure permise par la loi, nous excluons toute responsabilité pour les dommages directs, indirects, accessoires ou consécutifs.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">8. Indemnisation</h2>
              <p className="text-gray-700 mb-4">
                Vous acceptez de nous indemniser et de nous dégager de toute responsabilité concernant les réclamations résultant de votre utilisation de nos services ou de votre violation de ces conditions.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">9. Résiliation</h2>
              <p className="text-gray-700 mb-4">
                Nous nous réservons le droit de suspendre ou de résilier votre accès à nos services à tout moment, avec ou sans préavis, en cas de violation de ces conditions.
              </p>
              <p className="text-gray-700 mb-4">
                Vous pouvez également résilier votre compte à tout moment en nous contactant.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">10. Modifications des conditions</h2>
              <p className="text-gray-700 mb-4">
                Nous nous réservons le droit de modifier ces conditions à tout moment. Les modifications importantes vous seront notifiées par e-mail ou via une notification sur notre site.
              </p>
              <p className="text-gray-700 mb-4">
                Votre utilisation continue de nos services après la publication des modifications constitue votre acceptation des nouvelles conditions.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">11. Droit applicable</h2>
              <p className="text-gray-700 mb-4">
                Ces conditions sont régies par le droit français. Tout litige sera soumis à la juridiction exclusive des tribunaux français.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">12. Contact</h2>
              <p className="text-gray-700 mb-4">
                Pour toute question concernant ces conditions d'utilisation, contactez-nous :
              </p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700"><strong>Mon Kit Business</strong></p>
                <p className="text-gray-700">Email : legal@monkitbusiness.com</p>
                <p className="text-gray-700">Adresse : [Adresse de l'entreprise]</p>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  )
}

export default TermsOfService

