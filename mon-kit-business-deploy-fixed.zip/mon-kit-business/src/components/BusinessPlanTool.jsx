import React, { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Label } from '@/components/ui/label.jsx'
import { FileText, Download, Save, ArrowLeft } from 'lucide-react'
import { Link } from 'react-router-dom'

const BusinessPlanTool = () => {
  const [formData, setFormData] = useState({
    companyName: '',
    description: '',
    targetMarket: '',
    products: '',
    competition: '',
    marketing: '',
    financials: '',
    team: ''
  })

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleSave = () => {
    localStorage.setItem('businessPlan', JSON.stringify(formData))
    alert('Business plan sauvegardé avec succès!')
  }

  const handleExportPDF = () => {
    // Simulation d'export PDF
    alert('Fonctionnalité d\'export PDF en cours de développement')
  }

  const sections = [
    {
      id: 'companyName',
      title: 'Nom de l\'entreprise',
      description: 'Quel est le nom de votre entreprise?',
      type: 'input'
    },
    {
      id: 'description',
      title: 'Description de l\'entreprise',
      description: 'Décrivez votre entreprise en quelques phrases',
      type: 'textarea'
    },
    {
      id: 'targetMarket',
      title: 'Marché cible',
      description: 'Qui sont vos clients potentiels?',
      type: 'textarea'
    },
    {
      id: 'products',
      title: 'Produits et services',
      description: 'Quels produits ou services proposez-vous?',
      type: 'textarea'
    },
    {
      id: 'competition',
      title: 'Analyse concurrentielle',
      description: 'Qui sont vos principaux concurrents?',
      type: 'textarea'
    },
    {
      id: 'marketing',
      title: 'Stratégie marketing',
      description: 'Comment allez-vous promouvoir votre entreprise?',
      type: 'textarea'
    },
    {
      id: 'financials',
      title: 'Projections financières',
      description: 'Quelles sont vos prévisions de revenus et coûts?',
      type: 'textarea'
    },
    {
      id: 'team',
      title: 'Équipe',
      description: 'Présentez votre équipe et vos compétences',
      type: 'textarea'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à l'accueil
          </Link>
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mr-4">
              <FileText className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Générateur de Business Plan</h1>
              <p className="text-gray-600">Créez un business plan professionnel étape par étape</p>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button onClick={handleSave} variant="outline">
              <Save className="h-4 w-4 mr-2" />
              Sauvegarder
            </Button>
            <Button onClick={handleExportPDF}>
              <Download className="h-4 w-4 mr-2" />
              Exporter en PDF
            </Button>
          </div>
        </div>

        {/* Form Sections */}
        <div className="space-y-6">
          {sections.map((section) => (
            <Card key={section.id}>
              <CardHeader>
                <CardTitle>{section.title}</CardTitle>
                <CardDescription>{section.description}</CardDescription>
              </CardHeader>
              <CardContent>
                {section.type === 'input' ? (
                  <Input
                    value={formData[section.id]}
                    onChange={(e) => handleInputChange(section.id, e.target.value)}
                    placeholder={`Entrez ${section.title.toLowerCase()}`}
                    className="w-full"
                  />
                ) : (
                  <Textarea
                    value={formData[section.id]}
                    onChange={(e) => handleInputChange(section.id, e.target.value)}
                    placeholder={`Décrivez ${section.title.toLowerCase()}`}
                    className="w-full min-h-[120px]"
                  />
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Progress Indicator */}
        <Card className="mt-8">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">Progression</h3>
                <p className="text-sm text-gray-600">
                  {Object.values(formData).filter(value => value.trim() !== '').length} / {sections.length} sections complétées
                </p>
              </div>
              <div className="w-32 bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ 
                    width: `${(Object.values(formData).filter(value => value.trim() !== '').length / sections.length) * 100}%` 
                  }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default BusinessPlanTool

