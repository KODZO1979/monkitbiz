import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Calculator, ArrowLeft, TrendingUp, DollarSign } from 'lucide-react'
import { Link } from 'react-router-dom'

const FinancialSimulator = () => {
  const [inputs, setInputs] = useState({
    initialInvestment: '',
    monthlyRevenue: '',
    monthlyCosts: '',
    growthRate: '5'
  })

  const [results, setResults] = useState({
    breakEvenPoint: 0,
    monthlyProfit: 0,
    yearlyProfit: 0,
    roi: 0
  })

  const handleInputChange = (field, value) => {
    setInputs(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const calculateResults = () => {
    const initial = parseFloat(inputs.initialInvestment) || 0
    const revenue = parseFloat(inputs.monthlyRevenue) || 0
    const costs = parseFloat(inputs.monthlyCosts) || 0
    const growth = parseFloat(inputs.growthRate) || 0

    const monthlyProfit = revenue - costs
    const yearlyProfit = monthlyProfit * 12
    const breakEven = initial > 0 && monthlyProfit > 0 ? Math.ceil(initial / monthlyProfit) : 0
    const roi = initial > 0 ? ((yearlyProfit / initial) * 100) : 0

    setResults({
      breakEvenPoint: breakEven,
      monthlyProfit,
      yearlyProfit,
      roi
    })
  }

  useEffect(() => {
    calculateResults()
  }, [inputs])

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center text-purple-600 hover:text-purple-800 mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à l'accueil
          </Link>
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mr-4">
              <Calculator className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Simulateur Financier</h1>
              <p className="text-gray-600">Calculez vos projections financières et seuil de rentabilité</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Paramètres financiers</CardTitle>
                <CardDescription>Entrez vos données financières pour calculer vos projections</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="initialInvestment">Investissement initial (€)</Label>
                  <Input
                    id="initialInvestment"
                    type="number"
                    value={inputs.initialInvestment}
                    onChange={(e) => handleInputChange('initialInvestment', e.target.value)}
                    placeholder="50000"
                  />
                </div>
                <div>
                  <Label htmlFor="monthlyRevenue">Revenus mensuels estimés (€)</Label>
                  <Input
                    id="monthlyRevenue"
                    type="number"
                    value={inputs.monthlyRevenue}
                    onChange={(e) => handleInputChange('monthlyRevenue', e.target.value)}
                    placeholder="10000"
                  />
                </div>
                <div>
                  <Label htmlFor="monthlyCosts">Coûts mensuels (€)</Label>
                  <Input
                    id="monthlyCosts"
                    type="number"
                    value={inputs.monthlyCosts}
                    onChange={(e) => handleInputChange('monthlyCosts', e.target.value)}
                    placeholder="7000"
                  />
                </div>
                <div>
                  <Label htmlFor="growthRate">Taux de croissance mensuel (%)</Label>
                  <Input
                    id="growthRate"
                    type="number"
                    value={inputs.growthRate}
                    onChange={(e) => handleInputChange('growthRate', e.target.value)}
                    placeholder="5"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Scenarios */}
            <Card>
              <CardHeader>
                <CardTitle>Scénarios prédéfinis</CardTitle>
                <CardDescription>Utilisez ces exemples pour commencer</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => setInputs({
                      initialInvestment: '20000',
                      monthlyRevenue: '5000',
                      monthlyCosts: '3500',
                      growthRate: '3'
                    })}
                  >
                    Petite entreprise de services
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => setInputs({
                      initialInvestment: '100000',
                      monthlyRevenue: '25000',
                      monthlyCosts: '18000',
                      growthRate: '8'
                    })}
                  >
                    Startup technologique
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => setInputs({
                      initialInvestment: '50000',
                      monthlyRevenue: '12000',
                      monthlyCosts: '8000',
                      growthRate: '5'
                    })}
                  >
                    Commerce de détail
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results Section */}
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <TrendingUp className="h-8 w-8 text-green-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Bénéfice mensuel</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {formatCurrency(results.monthlyProfit)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <DollarSign className="h-8 w-8 text-blue-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Bénéfice annuel</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {formatCurrency(results.yearlyProfit)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <Calculator className="h-8 w-8 text-purple-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Seuil de rentabilité</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {results.breakEvenPoint > 0 ? `${results.breakEvenPoint} mois` : 'N/A'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <TrendingUp className="h-8 w-8 text-orange-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">ROI annuel</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {results.roi.toFixed(1)}%
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Projection Chart Placeholder */}
            <Card>
              <CardHeader>
                <CardTitle>Projection sur 12 mois</CardTitle>
                <CardDescription>Évolution des revenus et bénéfices</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-gradient-to-r from-purple-100 to-pink-100 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <TrendingUp className="h-12 w-12 text-purple-600 mx-auto mb-4" />
                    <p className="text-gray-600">Graphique de projection</p>
                    <p className="text-sm text-gray-500">Fonctionnalité en cours de développement</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Analysis */}
            <Card>
              <CardHeader>
                <CardTitle>Analyse</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {results.monthlyProfit > 0 ? (
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-green-800 font-medium">✓ Projet rentable</p>
                      <p className="text-green-600 text-sm">Votre entreprise génère des bénéfices dès le premier mois.</p>
                    </div>
                  ) : (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-red-800 font-medium">⚠ Attention</p>
                      <p className="text-red-600 text-sm">Les coûts dépassent les revenus. Révisez votre modèle économique.</p>
                    </div>
                  )}
                  
                  {results.roi > 20 && (
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-blue-800 font-medium">🚀 Excellent ROI</p>
                      <p className="text-blue-600 text-sm">Votre retour sur investissement est très attractif.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

export default FinancialSimulator

