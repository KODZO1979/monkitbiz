import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { X, Cookie, Shield, BarChart3, Target } from 'lucide-react'

const CookieSettings = ({ isOpen, onClose, onSave }) => {
  const [preferences, setPreferences] = useState({
    necessary: true, // Always true, cannot be disabled
    analytics: false,
    marketing: false,
    functional: false
  })

  useEffect(() => {
    // Load saved preferences from localStorage
    const saved = localStorage.getItem('cookiePreferences')
    if (saved) {
      setPreferences(JSON.parse(saved))
    }
  }, [])

  const handleSave = () => {
    localStorage.setItem('cookiePreferences', JSON.stringify(preferences))
    onSave(preferences)
    onClose()
  }

  const handleAcceptAll = () => {
    const allAccepted = {
      necessary: true,
      analytics: true,
      marketing: true,
      functional: true
    }
    setPreferences(allAccepted)
    localStorage.setItem('cookiePreferences', JSON.stringify(allAccepted))
    onSave(allAccepted)
    onClose()
  }

  const handleRejectAll = () => {
    const onlyNecessary = {
      necessary: true,
      analytics: false,
      marketing: false,
      functional: false
    }
    setPreferences(onlyNecessary)
    localStorage.setItem('cookiePreferences', JSON.stringify(onlyNecessary))
    onSave(onlyNecessary)
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Cookie className="h-6 w-6 text-orange-500 mr-2" />
              <h2 className="text-2xl font-bold text-gray-900">Paramètres des cookies</h2>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <p className="text-gray-600 mb-6">
            Nous utilisons des cookies pour améliorer votre expérience sur notre site. 
            Vous pouvez choisir quels types de cookies vous souhaitez accepter.
          </p>

          <div className="space-y-4">
            {/* Necessary Cookies */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 text-green-600 mr-2" />
                    <CardTitle className="text-lg">Cookies nécessaires</CardTitle>
                  </div>
                  <Switch checked={true} disabled />
                </div>
                <CardDescription>
                  Ces cookies sont essentiels au fonctionnement du site et ne peuvent pas être désactivés.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Ils permettent la navigation de base, la sécurité et l'accessibilité du site.
                </p>
              </CardContent>
            </Card>

            {/* Analytics Cookies */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <BarChart3 className="h-5 w-5 text-blue-600 mr-2" />
                    <CardTitle className="text-lg">Cookies d'analyse</CardTitle>
                  </div>
                  <Switch 
                    checked={preferences.analytics}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, analytics: checked }))
                    }
                  />
                </div>
                <CardDescription>
                  Ces cookies nous aident à comprendre comment vous utilisez notre site.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Ils collectent des informations anonymes sur les pages visitées et les interactions pour améliorer notre service.
                </p>
              </CardContent>
            </Card>

            {/* Marketing Cookies */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Target className="h-5 w-5 text-purple-600 mr-2" />
                    <CardTitle className="text-lg">Cookies marketing</CardTitle>
                  </div>
                  <Switch 
                    checked={preferences.marketing}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, marketing: checked }))
                    }
                  />
                </div>
                <CardDescription>
                  Ces cookies permettent de personnaliser les publicités et le contenu.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Ils suivent votre activité sur différents sites pour vous proposer du contenu pertinent.
                </p>
              </CardContent>
            </Card>

            {/* Functional Cookies */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Cookie className="h-5 w-5 text-orange-600 mr-2" />
                    <CardTitle className="text-lg">Cookies fonctionnels</CardTitle>
                  </div>
                  <Switch 
                    checked={preferences.functional}
                    onCheckedChange={(checked) => 
                      setPreferences(prev => ({ ...prev, functional: checked }))
                    }
                  />
                </div>
                <CardDescription>
                  Ces cookies améliorent les fonctionnalités et la personnalisation du site.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Ils mémorisent vos préférences et choix pour une meilleure expérience utilisateur.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 mt-8">
            <Button onClick={handleRejectAll} variant="outline" className="flex-1">
              Refuser tout
            </Button>
            <Button onClick={handleSave} variant="outline" className="flex-1">
              Sauvegarder les préférences
            </Button>
            <Button onClick={handleAcceptAll} className="flex-1">
              Accepter tout
            </Button>
          </div>

          <p className="text-xs text-gray-500 mt-4 text-center">
            Vous pouvez modifier vos préférences à tout moment en cliquant sur l'icône des cookies en bas de page.
          </p>
        </div>
      </div>
    </div>
  )
}

export default CookieSettings

