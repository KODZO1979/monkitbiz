import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { FileText, Calculator, Search, CheckSquare, Users, Scale, Star, Menu, X } from 'lucide-react'
import './App.css'

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [showCookieBanner, setShowCookieBanner] = useState(true)

  const tools = [
    {
      id: 'business-plan',
      title: 'Générateur de Business Plan',
      description: 'Créez un business plan professionnel étape par étape avec nos modèles guidés.',
      icon: FileText,
      features: ['Modèles professionnels', 'Export PDF', 'Sauvegarde automatique'],
      color: 'bg-blue-500'
    },
    {
      id: 'financial-simulator',
      title: 'Simulateur Financier',
      description: 'Calculez vos coûts de démarrage, prévisions de revenus et seuil de rentabilité.',
      icon: Calculator,
      features: ['Calculs automatiques', 'Graphiques visuels', 'Scénarios multiples'],
      color: 'bg-purple-500'
    },
    {
      id: 'market-study',
      title: 'Assistant Étude de Marché',
      description: 'Analysez votre marché cible avec des outils et questionnaires personnalisés.',
      icon: Search,
      features: ['Questionnaires types', 'Analyse concurrence', 'Rapports détaillés'],
      color: 'bg-green-500'
    },
    {
      id: 'startup-checklist',
      title: 'Checklist de Démarrage',
      description: 'Ne manquez aucune étape importante avec notre liste complète et interactive.',
      icon: CheckSquare,
      features: ['Suivi de progression', 'Rappels utiles', 'Personnalisable'],
      color: 'bg-orange-500'
    },
    {
      id: 'resources-directory',
      title: 'Annuaire de Ressources',
      description: 'Trouvez les organismes, aides et contacts utiles pour votre projet.',
      icon: Users,
      features: ['Base de données complète', 'Filtres par région', 'Contacts directs'],
      color: 'bg-indigo-500'
    },
    {
      id: 'legal-status',
      title: 'Calculateur de Statut',
      description: 'Choisissez le statut juridique optimal pour votre entreprise.',
      icon: Scale,
      features: ['Questionnaire guidé', 'Comparatif détaillé', 'Conseils personnalisés'],
      color: 'bg-red-500'
    }
  ]

  const testimonials = [
    {
      name: 'Marie Dubois',
      role: 'Fondatrice, EcoClean',
      content: 'Grâce aux outils, j\'ai pu structurer mon projet et convaincre mes investisseurs. Le business plan généré était parfait !',
      rating: 5
    },
    {
      name: 'Thomas Martin',
      role: 'CEO, TechStart',
      content: 'Le simulateur financier m\'a permis d\'éviter des erreurs coûteuses. Je recommande vivement cette plateforme.',
      rating: 5
    },
    {
      name: 'Sophie Laurent',
      role: 'Consultante indépendante',
      content: 'Interface intuitive et outils vraiment utiles. J\'ai gagné des semaines de travail sur mon étude de marché.',
      rating: 5
    }
  ]

  const stats = [
    { value: '10,000+', label: 'Entrepreneurs accompagnés' },
    { value: '6', label: 'Outils disponibles' },
    { value: '85%', label: 'Taux de réussite' },
    { value: '24/7', label: 'Support gratuit' }
  ]

  const navigation = [
    { name: 'Accueil', href: '#' },
    { name: 'Business Plan', href: '#business-plan' },
    { name: 'Simulateur Financier', href: '#financial-simulator' },
    { name: 'Étude de Marché', href: '#market-study' },
    { name: 'Checklist', href: '#startup-checklist' },
    { name: 'Ressources', href: '#resources-directory' },
    { name: 'Statut Juridique', href: '#legal-status' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Cookie Banner */}
      {showCookieBanner && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-50 p-4">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="text-orange-500 mt-1">🍪</div>
              <div>
                <h3 className="font-semibold text-gray-900">Nous utilisons des cookies</h3>
                <p className="text-sm text-gray-600">
                  Ce site utilise des cookies pour améliorer votre expérience de navigation, analyser le trafic et personnaliser le contenu. 
                  Certains cookies sont nécessaires au fonctionnement du site, d'autres nécessitent votre consentement.
                </p>
                <Link to="/privacy-policy" className="text-sm text-blue-600 hover:underline mt-1">
                  En savoir plus sur notre politique de cookies
                </Link>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setShowCookieBanner(false)}>
                Refuser tout
              </Button>
              <Button variant="outline" size="sm" onClick={() => setShowCookieBanner(false)}>
                Personnaliser
              </Button>
              <Button size="sm" onClick={() => setShowCookieBanner(false)}>
                Accepter tout
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold">
                  M
                </div>
                <span className="ml-2 text-xl font-bold text-gray-900">Mon Kit Business</span>
              </div>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-gray-500 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium transition-colors"
                >
                  {item.name}
                </a>
              ))}
            </nav>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500 p-2 rounded-md"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t">
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-gray-500 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </a>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Transformez votre idée en entreprise
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Des outils simples et gratuits pour accompagner les entrepreneurs débutants dans toutes les étapes de création de leur entreprise.
          </p>
          
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-blue-600 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Nos outils pour réussir
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Une suite complète d'outils conçus spécialement pour les entrepreneurs débutants
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {tools.map((tool) => {
              const IconComponent = tool.icon
              return (
                <Card key={tool.id} className="hover:shadow-lg transition-shadow duration-300">
                  <CardHeader>
                    <div className={`w-12 h-12 ${tool.color} rounded-lg flex items-center justify-center mb-4`}>
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-xl">{tool.title}</CardTitle>
                    <CardDescription className="text-gray-600">
                      {tool.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 mb-6">
                      {tool.features.map((feature, index) => (
                        <li key={index} className="flex items-center text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-2"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Link to={`/${tool.id}`}>
                      <Button className="w-full">
                        Utiliser l'outil
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Ce que disent nos utilisateurs
            </h2>
            <p className="text-xl text-gray-600">
              Découvrez comment nos outils ont aidé d'autres entrepreneurs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="text-center">
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-6 italic">"{testimonial.content}"</p>
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-500">{testimonial.role}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-blue-600 to-indigo-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Prêt à lancer votre entreprise ?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Rejoignez des milliers d'entrepreneurs qui ont déjà fait confiance à nos outils
          </p>
          <Button size="lg" variant="secondary" className="text-lg px-8 py-3">
            Commencer gratuitement
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold">
                  M
                </div>
                <span className="ml-2 text-xl font-bold">Mon Kit Business</span>
              </div>
              <p className="text-gray-400 mb-4">
                Des outils simples et gratuits pour accompagner les entrepreneurs débutants dans toutes les étapes de création de leur entreprise.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Outils</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Business Plan</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Simulateur Financier</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Étude de Marché</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Checklist</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/contact" className="hover:text-white transition-colors">Centre d'aide</Link></li>
                <li><Link to="/contact" className="hover:text-white transition-colors">Contact</Link></li>
                <li><Link to="/privacy-policy" className="hover:text-white transition-colors">Politique de confidentialité</Link></li>
                <li><Link to="/terms-of-service" className="hover:text-white transition-colors">Conditions d'utilisation</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Mon Kit Business. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

